#!/usr/bin/env python3
"""
Fix admin user password hash in database
"""

import asyncio
import asyncpg
import os
import bcrypt
from dotenv import load_dotenv

load_dotenv()

async def fix_admin_password():
    database_url = os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/anwalts_ai_db')
    
    try:
        conn = await asyncpg.connect(database_url)
        
        # Generate correct password hash for "admin123"
        password = "admin123"
        salt = bcrypt.gensalt()
        password_hash = bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
        
        print(f'Generated password hash: {password_hash}')
        
        # Update admin user with correct password hash
        result = await conn.execute(
            """
            UPDATE users 
            SET password_hash = $1 
            WHERE email = $2
            """,
            password_hash, 'admin@anwalts-ai.com'
        )
        
        print(f'Updated admin password: {result}')
        
        # Verify the update
        updated_user = await conn.fetchrow(
            'SELECT email, password_hash FROM users WHERE email = $1',
            'admin@anwalts-ai.com'
        )
        
        if updated_user:
            # Test password verification
            is_valid = bcrypt.checkpw(password.encode('utf-8'), updated_user['password_hash'].encode('utf-8'))
            print(f'Password verification test: {is_valid}')
        
        await conn.close()
        print('Admin password fixed successfully!')
        
    except Exception as e:
        print(f'Error fixing admin password: {e}')
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(fix_admin_password())